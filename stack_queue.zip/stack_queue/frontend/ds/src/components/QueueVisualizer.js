import React, { useState } from 'react';
import './QueueVisualizer.css';

const QueueVisualizer = () => {
  const [queue, setQueue] = useState([]);
  const [inputValue, setInputValue] = useState('');

  const enqueue = () => {
    if (inputValue.trim()) {
      setQueue((prevQueue) => [...prevQueue, inputValue]);
      setInputValue('');
    }
  };

  const dequeue = () => {
    setQueue((prevQueue) => prevQueue.slice(1));
  };

  return (
    <div className="visualizer">
      <div className="queue">
        {queue.map((item, index) => (
          <div key={index} className="queue-item">{item}</div>
        ))}
      </div>
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder="Enter value"
      />
      <button onClick={enqueue}>Enqueue</button>
      <button onClick={dequeue}>Dequeue</button>
    </div>
  );
};

export default QueueVisualizer;
