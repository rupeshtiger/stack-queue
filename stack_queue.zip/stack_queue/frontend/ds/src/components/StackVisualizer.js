import React, { useState } from 'react';
import './StackVisualizer.css';

const StackVisualizer = () => {
  const [stack, setStack] = useState([]);
  const [inputValue, setInputValue] = useState('');

  const push = () => {
    if (inputValue.trim()) {
      setStack((prevStack) => [...prevStack, inputValue]);
      setInputValue('');
    }
  };

  const pop = () => {
    setStack((prevStack) => prevStack.slice(0, -1));
  };

  return (
    <div className="visualizer">
      <div className="stack">
        {stack.map((item, index) => (
          <div key={index} className="stack-item">{item}</div>
        ))}
      </div>
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder="Enter value"
      />
      <button onClick={push}>Push</button>
      <button onClick={pop}>Pop</button>
    </div>
  );
};

export default StackVisualizer;
