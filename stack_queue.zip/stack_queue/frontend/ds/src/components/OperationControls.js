import React from 'react';
import './OperationControls.css';

const OperationControls = ({ setVisualizer }) => {
  const handleClick = (type) => () => setVisualizer(type);

  return (
    <div className="controls">
      <button onClick={handleClick('stack')}>Show Stack</button>
      <button onClick={handleClick('queue')}>Show Queue</button>
    </div>
  );
};

export default OperationControls;
