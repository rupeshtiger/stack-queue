import React, { useState } from 'react';
import StackVisualizer from './components/StackVisualizer';
import QueueVisualizer from './components/QueueVisualizer';
import OperationControls from './components/OperationControls';
import './App.css';

const App = () => {
  const [activeVisualizer, setActiveVisualizer] = useState('stack');

  return (
    <div className="App">
      <h1>{activeVisualizer === 'stack' ? 'Stack Visualizer' : 'Queue Visualizer'}</h1>
      {activeVisualizer === 'stack' ? (
        <StackVisualizer />
      ) : (
        <QueueVisualizer />
      )}
      <OperationControls setVisualizer={setActiveVisualizer} />
    </div>
  );
};

export default App;
